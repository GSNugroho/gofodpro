<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>GoFood Dashboard</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/materialize.css')?>" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="<?php echo base_url('assets/css/style.css')?>" type="text/css" rel="stylesheet" media="screen,projection"/>
  <style>
    .corousel .carousel-item{
      width: 340px !important;
      padding: 20px;
    }

    .card{
      border-radius: 8px;
      position: relative !important;
      right: 20px !important;
    }


  .page-flexbox-wrapper {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 1 auto;
  }
      
  </style>
</head>
<body>
  <div class="navbar-fixed">
  <nav class="white" role="navigation">
    <div class="nav-wrapper container">
      <ul class="right hide-on-med-and-down center">
        <li><a href="#">Home</a></li>
        <li><a href="#">Promos</a></li>
        <li><a href="#">Order</a></li>
        <li><a href="#">Chat</a></li>
      </ul>

      <ul id="nav-mobile" class="navigation">
        <li><a href="#">Home</a></li>
        <li><a href="#">Promos</a></li>
        <li><a href="#">Order</a></li>
        <li><a href="#">Chat</a></li>
      </ul>
      <!-- <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a> -->
    </div>
  </nav>
</div>

<div class="page-flexbox-wrapper">
<br>
<head>
  <div class="container">
    <form>
      <div class="input-field col s6">
        <i class="material-icons prefix">search</i>
        <input id="search" type="text">
        <label for="search">What would you like to eat?</label>
      </div>
    </form>
  </div>

  <div class="container">
    <div class="slider" style="height: 200;">
        <ul class="slides" style="height: 250;">
            <li>
                <img src="<?php echo base_url('assets/image/banner/top-banner-1-ID.jpg')?>" width="200px" height="120" style="object-fit:fill;">
            </li>
            <li>
                <img src="<?php echo base_url('assets/image/banner/top-banner-2-ID.jpg')?>" width="200px" height="120" style="object-fit:fill;">
            </li>
            <li>
                <img src="<?php echo base_url('assets/image/banner/top-banner-3-ID.jpg')?>" width="200px" height="120" style="object-fit:fill;">
            </li>
            <li>
                <img src="<?php echo base_url('assets/image/banner/top-banner-4-ID.jpg')?>" width="200px" height="120" style="object-fit:fill;">
            </li>
        </ul>
    </div>
  </div>
</head>
<main>
  <div class="container">
    <div class="section">
      <div class="row">
        <div class="col s12 center">
          <table class="responsive-table">
            <tr>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">map</i><br>Near Me</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">brightness_5</i><br>Best Seller</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">unarchive</i><br>Pickup</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">favorite</i><br>UMKM</a>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">local_atm</i><br>Budget</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">local_dining</i><br>Ready Cook</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">style</i><br>Promo</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">brightness_4</i><br>24 Hours</a>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">date_range</i><br>New Week</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">local_hospital</i><br>Healty</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">local_play</i><br>Most Loved</a>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Choose from cuisines</b></p>
          <p class="right"><a href="#" class="btn-small" style="background-color: green;border-radius: 50px;">See All</a></p>
          <table>
            <tr>
              <td>
                <div class="center-align">
                  <a href="#">
                    <img src="/gofood/image/img/foto_beverages.jpg" class="circle responsive-img" height="50px" width="50px">
                  <br>
                    <span class="black-text">
                      Beverages
                    </span>
                  </a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#">
                    <img src="/gofood/image/img/foto_beverages.jpg" class="circle responsive-img" height="50px" width="50px">
                  <br>
                    <span class="black-text">
                      Snacks
                    </span>
                  </a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#">
                    <img src="/gofood/image/img/foto_beverages.jpg" class="circle responsive-img" height="50px" width="50px">
                  <br>
                    <span class="black-text">
                      Sweets
                    </span>
                  </a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#">
                    <img src="/gofood/image/img/foto_beverages.jpg" class="circle responsive-img" height="50px" width="50px">
                  <br>
                    <span class="black-text">
                      Rice
                    </span>
                  </a>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Top-rated by other foodies</b></p>
        </div>
        <div class="col s12 left">
          <p style="margin-top: -18px;">Sponsored</p>
        </div>
        <div class="col s12">
          <div class="carousel carousel-slider">
            <?php
                foreach($toko as $row){
                    echo '
                    <a class="carousel-item black-text" href="'.base_url('Gofood/menu_toko/').$row['id'].'" style="width: 200px;">
                        <div class="card">
                            <div class="card-image">
                            <img src="/gofood/image/toko/foto_toko1.jpg">
                            </div>
                            <div class="card-content">
                            <h6>'.$row['jarak_toko'].'</h6>
                            <p><b>'.$row['nm_toko'].'</b></p>
                            <br>
                            <i class="material-icons">star</i>'.$row['ranting_toko'].'
                            </div>
                        </div>
                    </a>
                    ';
                }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Today Only! Extra #Promo</b></p>
          <p class="right"><a href="#" class="btn-small" style="background-color: green;border-radius: 50px;">See All</a></p>
        </div>
        <div class="col s12 left">
          <p style="margin-top: -18px;">Start the week with bombastic promos.</p>
        </div>
        <div class="col s12">
          <div class="carousel carousel-slider">
            <?php
                foreach($toko as $row){
                    echo '
                    <a class="carousel-item black-text" href="#" style="width: 200px;">
                        <div class="card">
                            <div class="card-image">
                                <img src="/gofood/image/toko/foto_toko1.jpg">
                            </div>
                            <div class="card-content">
                                <h6>'.$row['jarak_toko'].'</h6>
                                <p><b>'.$row['nm_toko'].'</b></p>
                                <br>
                                <i class="material-icons">star</i>'.$row['ranting_toko'].'
                            </div>
                        </div>
                    </a>
                    ';
                }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>GoFood's hidden gems</b></p>
          <p class="right"><a href="#" class="btn-small" style="background-color: green;border-radius: 50px;">See All</a></p>
        </div>
        <div class="col s12 left">
          <p style="margin-top: -18px;">Local restos loved by foodies in town.</p>
        </div>
        <div class="col s12">
          <div class="carousel carousel-slider">
          <?php
                foreach($toko as $row){
                    echo '
                    <a class="carousel-item black-text" href="#" style="width: 200px;">
                        <div class="card">
                            <div class="card-image">
                            <img src="/gofood/image/toko/foto_toko1.jpg">
                            </div>
                            <div class="card-content">
                            <h6>'.$row['jarak_toko'].'</h6>
                            <p><b>'.$row['nm_toko'].'</b></p>
                            <br>
                            <i class="material-icons">star</i>'.$row['ranting_toko'].'
                            </div>
                        </div>
                    </a>
                    ';
                }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Up-and-coming local restos</b></p>
        </div>
        <div class="col s12 left">
          <p style="margin-top: -18px;">People are buzzing about their food.</p>
        </div>
        <div class="col s12">
          <div class="carousel carousel-slider">
            <?php
                foreach($toko as $row){
                    echo '
                    <a class="carousel-item black-text" href="#" style="width: 200px;">
                        <div class="card">
                            <div class="card-image">
                            <img src="/gofood/image/toko/foto_toko1.jpg">
                            </div>
                            <div class="card-content">
                            <h6>'.$row['jarak_toko'].'</h6>
                            <p><b>'.$row['nm_toko'].'</b></p>
                            <br>
                            <i class="material-icons">star</i>'.$row['ranting_toko'].'
                            </div>
                        </div>
                    </a>
                    ';
                }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Whats's good 'round the block</b></p>
        </div>
        <div class="col s12">
            <p style="margin-top: -18px;">Try your area's finest eats.</p>
        </div>
        <div class="col s12">
            <?php
                foreach($toko as $row){
                    echo '
                        <a class="black-text" href="#" style="width: 200px;">
                            <div class="card horizontal" style="margin-left: 20px;">
                                <div class="card-image">
                                    <img src="/gofood/image/toko/foto_toko1.jpg" width="150px;" height="150px;">
                                </div>
                                <div class="card-stacked">
                                    <div class="card-content">
                                        <p>'.$row['nm_toko'].'</p>
                                        <p>'.$row['jarak_toko'].'</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    ';
                }
            ?>
            <button class="btn waves-effect waves-light" style="width: 100%;border-radius: 50px;background-color: green;">See more</button>
        </div>
      </div>
    </div>
  </div>
  </main>
  <footer class="page-footer white">
    <div class="container">
      <div class="row">
        <div class="col s3 center">
            <a class="red-text" href="#">
                <i class="material-icons">explore</i><br>Explore
            </a>
        </div>
        <div class="col s3 center">
            <a class="red-text" href="#">
                <i class="material-icons">unarchive</i><br>Pickup
            </a>
        </div>
        <div class="col s3 center">
            <a class="red-text" href="#">
                <i class="material-icons">search</i><br>Search
            </a>
        </div>
        <div class="col s3 center">
            <a class="red-text" href="#">
                <i class="material-icons">style</i><br>Promos
            </a>
        </div>
      </div>
    </div>
  </footer>
</div>

  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="<?php echo base_url('assets/js/materialize.js')?>"></script>
  <script src="<?php echo base_url('assets/js/init.js')?>"></script>

  </body>
</html>
