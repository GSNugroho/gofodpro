<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>GoFood Menu Dashboard</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/materialize.css')?>" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="<?php echo base_url('assets/css/style.css')?>" type="text/css" rel="stylesheet" media="screen,projection"/>
  <style>
    .corousel .carousel-item{
      width: 340px !important;
      padding: 20px;
    }

    .card{
      border-radius: 8px;
      position: relative !important;
      right: 20px !important;
    }


  .page-flexbox-wrapper {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 1 auto;
  }
      
  </style>
</head>
<body>
  <div class="navbar-fixed">
  <nav class="white" role="navigation">
    <div class="nav-wrapper container">
      <ul class="right hide-on-med-and-down center">
        <li><a href="<?php echo base_url('Gofood')?>">Home</a></li>
        <li><a href="<?php echo base_url('Gofood')?>">Promos</a></li>
        <li><a href="<?php echo base_url('Gofood')?>">Order</a></li>
        <li><a href="<?php echo base_url('Gofood')?>">Chat</a></li>
      </ul>

      <ul id="nav-mobile" class="navigation">
        <li><a href="<?php echo base_url('Gofood')?>">Home</a></li>
        <li><a href="<?php echo base_url('Gofood')?>">Promos</a></li>
        <li><a href="<?php echo base_url('Gofood')?>">Order</a></li>
        <li><a href="<?php echo base_url('Gofood')?>">Chat</a></li>
      </ul>
      <!-- <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a> -->
    </div>
  </nav>
</div>

<div class="page-flexbox-wrapper">
<br>
<head>
  <div class="container">
    <div class="row">
        <div class="col s12 left">
            <?php
                foreach($toko as $row){
                    echo '<p><b>'.$row['nm_toko'].'</b></p>';
                }
            ?>
        </div>
        <div class="col s12 left">
            <a href="#" class="btn-small" style="background-color: #c64d20; border-radius: 50px;"><i class="material-icons">thumb_up</i><span>Super Partner</span></a>
        </div>
    </div>
  </div>

  <div class="container">
      <div class="row">
          <div class="col s12 center">
              <?php foreach($toko as $row):?>
              <table>
                  <tr>
                      <td>
                          <div class="center">
                            <i class="material-icons">star</i><?= $row['ranting_toko']?>
                            <br>
                            Rantings
                          </div>
                      </td>
                      <td>
                          <div class="center">
                              <i class="material-icons">location_on</i><?= $row['jarak_toko']?>
                              <br>
                              Distance
                          </div>
                      </td>
                      <td>
                          <div class="center">
                              <i class="material-icons">attach_money</i>
                              <br>
                              16k++
                          </div>
                      </td>
                      <td>
                          <div class="center">
                              <i class="material-icons">thumb_up</i> ++
                              <br>
                              Great taste
                          </div>
                      </td>
                  </tr>
              </table>
              <?php endforeach;?>
          </div>
      </div>
  </div>
  <div class="container">
      <div class="row">
          <div class="col s12 left">
              <div class="card-panel">
                  <div class="row valign-wrapper" style="border-radius: 20px;">
                      <div class="col s3">
                          <img src="<?php echo base_url('assets/image/icon/motor_scooter.png')?>" alt="" class="circle responsive-img">
                      </div>
                      <div class="col s9">
                          <span class="black-text">
                              <p><b>Delivery</b><a class="waves-effect waves-light btn-small modal-trigger right" href="#modal1" style="background-color: green; border-radius: 50px;">Change</a></p>
                              <p>Delivery in 23 min</p>
                          </span>
                      </div>
                      <div id="modal1" class="modal bottom-sheet">
                        <div class="modal-content">
                            <h5>Select order type</h5>
                            <p>
                                <label>
                                    <input name="radio1" type="radio" checked />
                                    <span><b>Delivery</b></span>
                                    <br>
                                    <span>Delivery in 23 min</span>
                                </label>
                            </p>
                            <p>
                                <label>
                                    <input name="radio1" type="radio" />
                                    <span><b>Pickup</b></span>
                                    <br>
                                    <span>Pickup in 10 min</span>
                                </label>
                            </p>
                        </div>
                    </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</head>
<main>
  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Recommended</b></p>
        </div>
        <div class="col s12">
          
              <?php
                foreach($menu as $row){
                  if($row['best_seller'] == 1){
                    echo '
                    <div class="col s6">
                      <div class="left-align">
                        <a href="#" class="black-text">
                          <div class="card" style="height: 280px;max-height: 280px;">
                            <div class="card-image">
                              <img src="'.base_url('assets/image/toko/foto_toko1.jpg').'">
                            </div>
                            <div class="card-content" style="padding-left: 10px;padding-top: 10px; padding-right: 5px; padding-bottom: 10px; height: 100px; max-height: 100px;">
                              <h6><b>'.$row['nm_menu'].'</b></h6>
                              <p>'.$row['harga'].'</p>
                            </div>
                            <div class="card-action" style="padding-left: 5px;padding-top: 0px; padding-right: 5px; padding-bottom: 15px;">
                              <a class="btn-small" style="width: 100%;background-color: green; border-radius: 50px;">Add</a>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    ';
                  }
                }
              ?>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Menu Makanan</b></p>
        </div>
        <div class="col s12">
            <?php
                foreach($menu as $row){
                  if($row['kategori'] == 1){
                    echo '
                      <a class="black-text" href="#" style="width: 200px;">
                          <div class="card horizontal" style="margin-left: 20px;">
                              <div class="card-image" style="max-width: 100%;">
                                  <img src="/gofood/image/toko/foto_toko1.jpg" width="150px;" height="150px;">
                              </div>
                              <div class="card-stacked">
                                  <div class="card-content">
                                      <p>'.$row['nm_menu'].'</p>
                                      <p>'.$row['harga'].'</p>
                                  </div>
                                  <div class="card-action">
                                    <a class="btn-small" style="width: 100%;background-color: green; border-radius: 50px;">Add</a>
                                  </div>
                              </div>
                          </div>
                      </a>
                  ';
                  }
                }
            ?>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Menu Minuman</b></p>
        </div>
        <div class="col s12">
          <?php
            foreach($menu as $row){
              if($row['kategori'] == 2){
                echo '
                <a class="black-text" href="#" style="width: 200px;">
                  <div class="card horizontal" style="margin-left: 20px;">
                      <div class="card-image" style="max-width: 100%;">
                          <img src="/gofood/image/toko/foto_toko1.jpg" width="150px;" height="150px;">
                      </div>
                      <div class="card-stacked">
                          <div class="card-content">
                              <p>'.$row['nm_menu'].'</p>
                              <p>'.$row['harga'].'</p>
                          </div>
                          <div class="card-action">
                            <a class="btn-small" style="width: 100%;background-color: green; border-radius: 50px;">Add</a>
                          </div>
                      </div>
                  </div>
                </a>
                ';
              }
            }
          ?>
        </div>
      </div>
    </div>
  </div>
  </main>
  <footer class="page-footer white">
    <!-- <div class="container">
      <div class="row">
        <div class="col s3 center">
            <a class="red-text" href="#">
                <i class="material-icons">explore</i><br>Explore
            </a>
        </div>
        <div class="col s3 center">
            <a class="red-text" href="#">
                <i class="material-icons">unarchive</i><br>Pickup
            </a>
        </div>
        <div class="col s3 center">
            <a class="red-text" href="#">
                <i class="material-icons">search</i><br>Search
            </a>
        </div>
        <div class="col s3 center">
            <a class="red-text" href="#">
                <i class="material-icons">style</i><br>Promos
            </a>
        </div>
      </div>
    </div> -->
    <div class="fixed-action-btn">
      <a class="btn-floating btn-small red" style="border-radius: 50px;width: 120px;">
        <p style="margin-top: -2px;">
          <i class="small material-icons">room_service</i>Menu
        </p>
      </a>
      <ul>
        <li><a class="btn-floating red"><i class="material-icons">insert_chart</i></a></li>
        <li><a class="btn-floating yellow darken-1"><i class="material-icons">format_quote</i></a></li>
        <li><a class="btn-floating green"><i class="material-icons">publish</i></a></li>
        <li><a class="btn-floating blue"><i class="material-icons">attach_file</i></a></li>
      </ul>
    </div>
  </footer>
</div>

  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="<?php echo base_url('assets/js/materialize.js')?>"></script>
  <script src="<?php echo base_url('assets/js/init.js')?>"></script>

  </body>
</html>
