<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_gofood extends CI_Model{
    public function get_all_toko(){
        $sql = "SELECT * FROM gofood_toko";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function get_all_menu_toko($id){
        $sql = "SELECT * FROM gofood_menu WHERE gofood_menu.id_toko = '$id'";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function get_info_toko($id){
        $sql = "SELECT * FROM gofood_toko WHERE gofood_toko.id = '$id'";
        $query = $this->db->query($sql);
        return $query->result_array();
    }
}
?>