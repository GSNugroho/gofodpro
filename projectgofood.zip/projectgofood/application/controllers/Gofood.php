<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gofood extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_gofood');
    }

	public function index()
	{
        $data = array(
            'toko' => $this->M_gofood->get_all_toko()
        );
		$this->load->view('gofood/gofood_dashboard', $data);
	}

    public function menu_toko($id){
        $kode_toko = $id;

        $data = array(
            'toko' => $this->M_gofood->get_info_toko($kode_toko),
            'menu' => $this->M_gofood->get_all_menu_toko($kode_toko)
        );

        $this->load->view('gofood/gofood_menu', $data);
    }
}
?>