(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.parallax').parallax();
    $('.slider').slider();
    $('.carousel').carousel({full_width: true, numVisible: 10});
    $('.modal').modal();

  }); // end of document ready
})(jQuery); // end of jQuery name space
