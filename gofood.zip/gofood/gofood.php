<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Parallax Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <style>
    .corousel .carousel-item{
      width: 340px !important;
      padding: 20px;
    }

    .card{
      border-radius: 8px;
      position: relative !important;
      right: 20px !important;
    }
  </style>
</head>
<body>
  <div class="navbar-fixed">
  <nav class="white" role="navigation">
    <div class="nav-wrapper container">
      <ul class="right hide-on-med-and-down center">
        <li><a href="#">Home</a></li>
        <li><a href="#">Promos</a></li>
        <li><a href="#">Order</a></li>
        <li><a href="#">Chat</a></li>
      </ul>

      <ul id="nav-mobile" class="navigation">
        <li><a href="#">Home</a></li>
        <li><a href="#">Promos</a></li>
        <li><a href="#">Order</a></li>
        <li><a href="#">Chat</a></li>
      </ul>
      <!-- <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a> -->
    </div>
  </nav>
</div>

<br>
  <div class="container">
    <form>
      <div class="input-field col s6">
        <i class="material-icons prefix">search</i>
        <input id="search" type="text">
        <label for="search">What would you like to eat?</label>
      </div>
    </form>
  </div>

  <div class="container">
    <div class="slider" style="height: 200;">
        <ul class="slides" style="height: 250;">
            <li>
                <img src="/gofood/image/banner/top-banner-ID.jpg" width="200px" height="120">
            </li>
            <li>
                <img src="/gofood/image/banner/top-banner-2-ID.jpg" width="200px" height="120">
            </li>
            <li>
                <img src="/gofood/image/banner/top-banner-ID.jpg" width="200px" height="120">
            </li>
            <li>
                <img src="/gofood/image/banner/top-banner-2-ID.jpg" width="200px" height="120">
            </li>
        </ul>
    </div>
  </div>

  <div class="container">
    <div class="section">
      <div class="row">
        <div class="col s12 center">
          <table class="responsive-table">
            <tr>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">map</i><br>Near Me</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">brightness_5</i><br>Best Seller</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">unarchive</i><br>Pickup</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">favorite</i><br>UMKM</a>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">local_atm</i><br>Budget</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">local_dining</i><br>Ready Cook</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">style</i><br>Promo</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">brightness_4</i><br>24 Hours</a>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">date_range</i><br>New Week</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">local_hospital</i><br>Healty</a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#"><i class="material-icons">local_play</i><br>Most Loved</a>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Choose from cuisines</b></p>
          <p class="right"><a href="#">See All</a></p>
          <table>
            <tr>
              <td>
                <div class="center-align">
                  <a href="#">
                    <img src="/gofood/image/img/foto_beverages.jpg" class="circle responsive-img" height="50px" width="50px">
                  <br>
                    <span class="black-text">
                      Beverages
                    </span>
                  </a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#">
                    <img src="/gofood/image/img/foto_beverages.jpg" class="circle responsive-img" height="50px" width="50px">
                  <br>
                    <span class="black-text">
                      Snacks
                    </span>
                  </a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#">
                    <img src="/gofood/image/img/foto_beverages.jpg" class="circle responsive-img" height="50px" width="50px">
                  <br>
                    <span class="black-text">
                      Sweets
                    </span>
                  </a>
                </div>
              </td>
              <td>
                <div class="center-align">
                  <a href="#">
                    <img src="/gofood/image/img/foto_beverages.jpg" class="circle responsive-img" height="50px" width="50px">
                  <br>
                    <span class="black-text">
                      Rice
                    </span>
                  </a>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Top-rated by other foodies</b></p>
        </div>
        <div class="col s12 left">
          <p style="margin-top: -18px;">Sponsored</p>
        </div>
        <div class="col s12">
          <!-- <div class="carousel">
            <a href="#" class="carousel-item">
              <div class="card" style="margin-top:-100px;">
                <div class="card-image">
                  <img src="/gofood/image/toko/foto_toko1.jpg">
                </div>
                <div class="card-content">
                  <h6 class="black-text">0.9 km</h6>
                    <p class="black-text"><b>Warung Spesial Ayam Geprek, Penumping</b></p>
                  <br>
                  <span class="black-text">
                    <i class="material-icons">star</i>4.5
                  </span>
                </div>
              </div>
            </a>
            <a href="#" class="carousel-item">
              <div class="card" style="margin-top:-100px;">
                <div class="card-image">
                  <img src="/gofood/image/toko/foto_toko2.jpg">
                </div>
                <div class="card-content">
                  <h6 class="black-text">0.5 km</h6>
                    <p class="black-text"><b>Tacitos Solo</b></p>
                  <br>
                  <span class="black-text">
                    <i class="material-icons">star</i>4.5
                  </span>
                </div>
              </div>
            </a>
          </div> -->
          <div class="carousel carousel-slider">
            <a class="carousel-item black-text" href="#" style="width: 200px;">
              <div class="card">
                <div class="card-image">
                  <img src="/gofood/image/toko/foto_toko1.jpg">
                </div>
                <div class="card-content">
                  <h6>0.9 km</h6>
                  <p><b>Warung Spesial Ayam Geprek, P</b></p>
                  <br>
                  <i class="material-icons">star</i>4.5
                </div>
              </div>
            </a>
            <a class="carousel-item black-text" href="#" style="width: 200px;">
              <div class="card">
                <div class="card-image">
                  <img src="/gofood/image/toko/foto_toko1.jpg">
                </div>
                <div class="card-content">
                  <h6>0.5 km</h6>
                  <p><b>Bakmi Solo, Manahan</b></p>
                  <br>
                  <i class="material-icons">star</i>4.8
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Today Only! Extra #Promo</b></p>
          <p class="right"><a href="#">See All</a></p>
        </div>
        <div class="col s12 left">
          <p style="margin-top: -18px;">Start the week with bombastic promos.</p>
        </div>
        <div class="col s12">
          <div class="carousel carousel-slider">
            <a class="carousel-item black-text" href="#" style="width: 200px;">
              <div class="card">
                <div class="card-image">
                  <img src="/gofood/image/toko/foto_toko1.jpg">
                </div>
                <div class="card-content">
                  <h6>1.4 km</h6>
                  <p><b>Rumah Makan Padang Sederhana</b></p>
                  <br>
                  <i class="material-icons">star</i>4.6
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>GoFood's hidden gems</b></p>
          <p class="right"><a href="#">See All</a></p>
        </div>
        <div class="col s12 left">
          <p style="margin-top: -18px;">Local restos loved by foodies in town.</p>
        </div>
        <div class="col s12">
          <div class="carousel carousel-slider">
            <a class="carousel-item black-text" href="#" style="width: 200px;">
              <div class="card">
                <div class="card-image">
                  <img src="/gofood/image/toko/foto_toko1.jpg">
                </div>
                <div class="card-content">
                  <h6>0.8 km</h6>
                  <p><b>Ayam Bakar Bu Puji, Laweyan</b></p>
                  <br>
                  <i class="material-icons">star</i>4.8
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>Up-and-coming local restos</b></p>
        </div>
        <div class="col s12 left">
          <p style="margin-top: -18px;">People are buzzing about their food.</p>
        </div>
        <div class="col s12">
          <div class="carousel carousel-slider">
            <a class="carousel-item black-text" href="#" style="width: 200px;">
              <div class="card">
                <div class="card-image">
                  <img src="/gofood/image/toko/foto_toko1.jpg">
                </div>
                <div class="card-content">
                  <h6>1.2 km</h6>
                  <p><b>Roti Gembong Gedhe, Slamet Riyadi</b></p>
                  <br>
                  <i class="material-icons">star</i>4.8
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="selection">
      <div class="row">
        <div class="col s12 center">
          <p class="left"><b>All prices chopped!</b></p>
          <p class="right"><a href="#">See All</a></p>
        </div>
        <div class="col s12">
          <div class="carousel carousel-slider">
            <a class="carousel-item black-text" href="#" style="width: 400px;">
              <div class="card horizontal">
                <div class="card-image">
                  <img src="/gofood/image/toko/foto_toko1.jpg">
                </div>
                <div class="card-stacked">
                  <div class="card-content">
                    <h6>0.8 km</h6>
                    <p><b>Indo Mie Wagyu</b></p>
                    <br>
                    <h6>18.000</h6>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="parallax-container valign-wrapper">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h5 class="header col s12 light">A modern responsive front-end framework based on Material Design</h5>
        </div>
      </div>
    </div>
    <div class="parallax"><img src="background3.jpg" alt="Unsplashed background img 3"></div>
  </div>

  <footer class="page-footer teal">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">Company Bio</h5>
          <p class="grey-text text-lighten-4">We are a team of college students working on this project like it's our full time job. Any amount would help support and continue development on this project and is greatly appreciated.</p>


        </div>
        <div class="col l3 s12">
          <h5 class="white-text">Settings</h5>
          <ul>
            <li><a class="white-text" href="#!">Link 1</a></li>
            <li><a class="white-text" href="#!">Link 2</a></li>
            <li><a class="white-text" href="#!">Link 3</a></li>
            <li><a class="white-text" href="#!">Link 4</a></li>
          </ul>
        </div>
        <div class="col l3 s12">
          <h5 class="white-text">Connect</h5>
          <ul>
            <li><a class="white-text" href="#!">Link 1</a></li>
            <li><a class="white-text" href="#!">Link 2</a></li>
            <li><a class="white-text" href="#!">Link 3</a></li>
            <li><a class="white-text" href="#!">Link 4</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

  </body>
</html>
